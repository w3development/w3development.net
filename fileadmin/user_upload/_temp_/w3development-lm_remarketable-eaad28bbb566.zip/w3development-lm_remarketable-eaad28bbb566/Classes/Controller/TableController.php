<?php

namespace LiermannMedien\LmRemarketable\Controller;

use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;

/**
 * Class TableController
 *
 * @package LiermannMedien\LmRemarketable\Controller
 */
class TableController extends ActionController
{
    function listAction(){

        $api_domain     = trim( $this->settings["api_url"] );
        $api_key        = trim( $this->settings["api_key"] );
        $api_segment    = trim( $this->settings["api_segment"] );

        $path = "bonus/remarketable-models";

        $api_path = $api_domain . "/" . $api_segment . "/" . $path .'?apikey=' . $api_key;

        $result = $this->fetchAPI($api_path);

        $this->view->assign("result", $result);
    }

    function fetchAPI($url){

        $result = @file_get_contents($url);

        return $result;
    }

    /**
     * downloadExcel
     *
     * @return void
     */
    public function downloadAction()
    {

        $api_domain     = trim( $this->settings["api_url"] );
        $api_key        = "InhySu8PZ3C3UTXRM9nEAcsjZgUpg67Ojda1x9Fk25dLO0qqXESlG9stfdIl7EX";
        $api_segment    = trim( $this->settings["api_segment"] );

        $path = "bonus/remarketable-models_spreadsheet";

        $api_path = $api_domain . "/" . $api_segment . "/" . $path .'?apikey=' . $api_key;

        $url = "https://dc.rsd-mobileapps.net/singularity/bonus/remarketable-models_spreadsheet?apikey=InhySu8PZ3C3UTXRM9nEAcsjZgUpg67Ojda1x9Fk25dLO0qqXESlG9stfdIl7EX";


        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0"); 
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=remarketable-models.xls ");
        header("Content-Transfer-Encoding: binary ");
        @readfile($api_path); die;

    }
}