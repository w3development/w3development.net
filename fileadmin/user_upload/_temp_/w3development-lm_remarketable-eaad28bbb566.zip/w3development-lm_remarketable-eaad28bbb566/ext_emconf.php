<?php

$EM_CONF[$_EXTKEY] = array(
    'title' => 'LM: Remarketable',
    'description' => '',
    'category' => 'plugin',
    'author' => 'Markus Liermann',
    'author_email' => 'markus@liermann-medien.de',
    'state' => 'alpha',
    'clearCacheOnLoad' => true,
    'version' => '0.0.1',
    'constraints' => [
        'depends' => [
            'typo3' => '8.7-9.9',
        ],
    ],
    'autoload' => [
        'psr-4' => [
            'LiermannMedien\\LmRemarketable\\' => 'Classes/'
        ]
    ],
);