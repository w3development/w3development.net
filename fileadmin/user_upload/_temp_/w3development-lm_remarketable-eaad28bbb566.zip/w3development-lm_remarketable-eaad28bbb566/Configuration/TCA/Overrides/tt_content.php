<?php

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
    'LiermannMedien.LmRemarketable',
    'Pi1',
    'LmRemarketable',
    'EXT:lm_remarketable/Resources/Public/Icons/Extension.svg'
);