<?php
defined('TYPO3_MODE') || die('Access denied.');

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
    "LiermannMedien.LmRemarketable",    // Extension name
    'Pi1',                              // Plugin name
    [ 'Table' => 'list, download' ],              // Cacheable actions
    [ 'Table' => 'list, download' ]               // Non-cacheable actions
);

call_user_func(
    function() {
       $extensionKey = 'lm_remarketable';

        /**
        * Default TypoScript Constants
        */
       \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTypoScript(
            $extensionKey,
            'constants',
            "@import 'EXT:" . $extensionKey . "/Configuration/TypoScript/constants.typoscript'"
        );

        /**
        * Default TypoScript Setup
        */
       \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTypoScript(
            $extensionKey,
            'setup',
            "@import 'EXT:" . $extensionKey . "/Configuration/TypoScript/setup.typoscript'"
        );
    }
);